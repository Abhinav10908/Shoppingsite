<?php 
    // // Define database credentials as constants
    // define('DB_SERVER', 'sql101.infinityfree.com');
    // define('DB_USERNAME', 'if0_39187018');
    // define('DB_PASSWORD', 'SS7rYQ8ZH6Wbjp6');
    // define('DB_NAME', 'if0_39187018_shoping');

    // // Create connection
    // $conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

    // // Check connection

    
    $server="Localhost";
    $username="root";
    $password="Ayush@1234";
    $db="USER_CRED";
    $conn=mysqli_connect($server,$username,$password,$db);
    

?>
